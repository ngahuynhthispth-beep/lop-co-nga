# Changelog: C�ng Con H?c Gi?i (L?p C� H.Nga)

## [2026-03-31]
### Added
- Kh?i t?o d? �n Web App (Express + SQLite).
- Giao di?n Student View: Ch?n t�n (38 h?c sinh), n?p ?nh/Video.
- Giao di?n Teacher View: Ch?m sao (3-10), l?i ph� t? d?ng.
- B?ng tin l?p h?c hi?n th? b�i t?p d� ch?m.
- H? th?ng n?p danh s�ch h?c sinh t? file `students.txt`.

### Changed
- C?p nh?t danh s�ch th?t 38 h?c sinh (Trung Qu�n - Tu?n Anh).
