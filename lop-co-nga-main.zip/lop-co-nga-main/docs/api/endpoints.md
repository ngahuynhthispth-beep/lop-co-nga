# API Documentation

Ng�y c?p nh?t: 31-03-2026
Base URL: http://localhost:3000

---

## ?? H?c sinh & L?p h?c
### GET /api/students
L?y danh s�ch 38 b?n nh?.

### GET /api/wall
L?y c�c b�i d� du?c c� ch?m di?m d? hi?n l�n b?ng tin.

---

## ?? Ch?m & N?p b�i
### POST /api/upload
H?c sinh n?p ?nh ho?c video.

### POST /api/grade
C� ch?m di?m b?ng s? sao v� th�m l?i ph� (t? d?ng g?i �).

### GET /api/pending
Danh s�ch b�i t?p c� chua ch?m.
